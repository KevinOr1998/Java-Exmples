/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package SegundoParcial;

import java.util.Scanner;

/**
 *
 * @author Kevin Ortega
 */
public class BinarioADECIMAL {
    public static void main(String[]args){
  
      String codigo="";
      String arreglo;
      char comparar;
      int a=7;
      Scanner teclado=new Scanner(System.in);
      
        int decimal=0;
        
      
      while(true){
          System.out.println("Introduce el codigo binario");
          arreglo=teclado.nextLine();
           char[] arreglo1=arreglo.toCharArray();

        //Con las siguientes calculamos el numero decimal
        for(int b=0;b<arreglo1.length  ;b++){
       comparar=arreglo1[b];
            if(comparar=='1'){
                decimal=(int)(decimal+Math.pow(2,a));
                        }
            a--;
                  }
         
          codigo=Integer.toString(decimal);
          System.out.println("  El codigo binario es "+codigo);
          System.out.println("");
          decimal=0;
          a=7;
      }
    }
    
}
