/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PrimerParcial;

/**
 *
 * @author Kevin Ortega
 */
public class Aritmetica {
    public static void main(String[]args){
        int a=27;
        int b=9;
                System.out.println("a="+a+" y b="+b);
        System.out.println("a+b="+(a+b));
                System.out.println("a-b="+(a-b));
                        System.out.println("a*b=+(a*b)");
                                System.out.println("a/b=+"+(a/b));
    }
}
