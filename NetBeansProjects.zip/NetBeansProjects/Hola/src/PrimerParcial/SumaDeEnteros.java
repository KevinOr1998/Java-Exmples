/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PrimerParcial;

/**
 *
 * @author Kevin Ortega
 */
public class SumaDeEnteros {
    public static void main(String[]args){
        int a=5;
        int b=10;
        int z;
        z=a+b;
        System.out.println("la suma de a + b="+z);
    }
    
}
