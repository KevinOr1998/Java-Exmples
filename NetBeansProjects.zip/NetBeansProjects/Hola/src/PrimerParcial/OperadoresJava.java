/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package PrimerParcial;

/**
 *
 * @author Kevin Ortega
 */
public class OperadoresJava {
    	public static void main(String args[]){
		int a;
		int b;
		int c;
		a=5;
		b=5;
		c=-12;
		System.out.println(a>3);
		System.out.println(a>c);
		System.out.println(a<c);
		System.out.println(a*b==-30);
		System.out.println(c/b<a);


	}
}
