/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basededatos;

import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kevin Ortega
 */
public class Menu extends javax.swing.JFrame {

    public Menu() {
        initComponents();
        grupoOpciones = new ButtonGroup(); // crea ButtonGroup
        grupoOpciones.add( RadioAltas ); // agrega simple al grupo
        grupoOpciones.add( RadioBajas ); // agrega negrita al grupo
        grupoOpciones.add( RadioConsultar );
        grupoOpciones.add( RadioModificar );
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        RadioAltas = new javax.swing.JRadioButton();
        RadioBajas = new javax.swing.JRadioButton();
        RadioConsultar = new javax.swing.JRadioButton();
        RadioModificar = new javax.swing.JRadioButton();
        BSiguiente = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu");
        setLocation(new java.awt.Point(700, 250));
        setResizable(false);

        RadioAltas.setText("Altas");

        RadioBajas.setText("Bajas");

        RadioConsultar.setText("Consultar");

        RadioModificar.setText("Modificar");

        BSiguiente.setText("Siguiente");
        BSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSiguienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RadioBajas)
                            .addComponent(RadioAltas)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RadioConsultar)
                            .addComponent(RadioModificar)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(BSiguiente)))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(RadioAltas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RadioBajas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioConsultar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RadioModificar)
                .addGap(18, 18, 18)
                .addComponent(BSiguiente)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSiguienteActionPerformed
        
        if(RadioBajas.isSelected()==false && RadioAltas.isSelected()==false && RadioConsultar.isSelected()==false && RadioModificar.isSelected()==false   ){

            JOptionPane.showMessageDialog(this, "Seleccione una opcion", "    MENSAJE", JOptionPane.INFORMATION_MESSAGE);
        }else{
            newUsuario.setRadioSeleccionadoUsuario(getRadioSeleccionadoMenu());
            this.setVisible(false);
            newUsuario.setVisible(true); 
        }
           
    }//GEN-LAST:event_BSiguienteActionPerformed
    
    public String getRadioSeleccionadoMenu(){
       if(RadioAltas.isSelected()){
           radio=RadioAltas.getText();
       }else if(RadioBajas.isSelected()){
           radio=RadioBajas.getText();
       }else if(RadioConsultar.isSelected()){
           radio=RadioConsultar.getText();
       }else if(RadioModificar.isSelected()){
           radio=RadioModificar.getText();
       }
       return radio;
   }
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BSiguiente;
    private javax.swing.JRadioButton RadioAltas;
    private javax.swing.JRadioButton RadioBajas;
    private javax.swing.JRadioButton RadioConsultar;
    private javax.swing.JRadioButton RadioModificar;
    // End of variables declaration//GEN-END:variables
   String radio;
   CRUD crud=new CRUD();
   ButtonGroup grupoOpciones;
   boolean conexionMenu;
   Usuarios newUsuario= new Usuarios();

}
