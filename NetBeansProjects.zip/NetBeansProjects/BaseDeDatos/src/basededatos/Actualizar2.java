
package basededatos;

import com.mysql.jdbc.Connection;
import javax.swing.JTextField;

public class Actualizar2 extends javax.swing.JFrame {

    public Actualizar2() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        MatriculaActualizar = new javax.swing.JTextField();
        NombreActualizar = new javax.swing.JTextField();
        ApPaternoActualizar = new javax.swing.JTextField();
        ApMaternoActualizar = new javax.swing.JTextField();
        BtnActualizar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(700, 250));

        jLabel3.setText("Apellido paterno");

        jLabel4.setText("Apellido Materno");

        MatriculaActualizar.setEditable(false);

        BtnActualizar.setText("Actualizar");
        BtnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActualizarActionPerformed(evt);
            }
        });

        jLabel1.setText("Matricula");

        jLabel2.setText("Nombre");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(241, Short.MAX_VALUE)
                .addComponent(BtnActualizar)
                .addGap(80, 80, 80))
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(MatriculaActualizar)
                        .addComponent(NombreActualizar)
                        .addComponent(ApPaternoActualizar)
                        .addComponent(ApMaternoActualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(MatriculaActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(NombreActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addGap(10, 10, 10)
                .addComponent(ApPaternoActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(9, 9, 9)
                .addComponent(ApMaternoActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BtnActualizar)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActualizarActionPerformed
        crudActualizar=getConexionActualizar();
        crudActualizar.Modificar(getMatriculaActualizar(), getNombreActualizar(), getApPaternoActualizar(), getApMaternoActualizar());
        if(crudActualizar.getEstadoMod()==true){
            dispose();
        }
        
        /*if(getConexionActualizar().getValorDeConexionCRUDE()==true){
            dispose();
        }  */
        
        
    }//GEN-LAST:event_BtnActualizarActionPerformed

    public String  getApMaternoActualizar() {
        return ApMaternoActualizar.getText();
    }

    public void setApMaternoActualizar(String  ApMaternoActualizarNuevo) {
        ApMaternoActualizar.setText(ApMaternoActualizarNuevo);
    }

    public String  getApPaternoActualizar() {
        return ApPaternoActualizar.getText();
    }

    public void setApPaternoActualizar(String  ApPaternoActualizarNuevo) {
        ApPaternoActualizar.setText(ApPaternoActualizarNuevo);
    }

    public String  getMatriculaActualizar() {
        return MatriculaActualizar.getText();
    }

    public void setMatriculaActualizar2(String MatriculaActualizarNueva) {
        MatriculaActualizar.setText(MatriculaActualizarNueva);
    }

    public String getNombreActualizar() {
        return NombreActualizar.getText();
    }

    public void setNombreActualizar(String NombreActualizarNuevo) {
        NombreActualizar.setText(NombreActualizarNuevo);
    }



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ApMaternoActualizar;
    private javax.swing.JTextField ApPaternoActualizar;
    private javax.swing.JButton BtnActualizar;
    private javax.swing.JTextField MatriculaActualizar;
    private javax.swing.JTextField NombreActualizar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
String matriculaActualizar;
Connection conexionActualizar=null;
CRUD crudActualizar=new CRUD();

   public void setConexionActualizar(CRUD conexion){
        crudActualizar=conexion;
    }
   public  CRUD getConexionActualizar(){
        return crudActualizar;
    }
}
