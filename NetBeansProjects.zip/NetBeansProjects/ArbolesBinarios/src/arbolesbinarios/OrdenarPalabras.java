/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package arbolesbinarios;

import java.util.Scanner;

/**
 *
 * @author Kevin Ortega
 */
public class OrdenarPalabras {
    Scanner teclado=new Scanner(System.in);
    String decicion="";

    
}
