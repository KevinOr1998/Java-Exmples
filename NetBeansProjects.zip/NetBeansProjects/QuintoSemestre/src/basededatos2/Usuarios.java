/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basededatos2;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author Kevin Ortega
 */
public class Usuarios extends javax.swing.JFrame {

    public Usuarios() {
        initComponents();
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        BotonEntrar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Usuario = new javax.swing.JTextField();
        Host = new javax.swing.JTextField();
        Contraseña = new javax.swing.JPasswordField();
        btnRegresar = new javax.swing.JButton();

        setTitle("Iniciar Sesion");
        setLocation(new java.awt.Point(700, 200));
        setName("InicioDeSesion"); // NOI18N

        jLabel1.setText("USUARIOS");

        BotonEntrar.setText("Entrar");
        BotonEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonEntrarActionPerformed(evt);
            }
        });

        jLabel2.setText("CONTRASEÑÁ");

        jLabel3.setText("HOST");

        Contraseña.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(Usuario, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Contraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                        .addComponent(Host))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BotonEntrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                        .addComponent(btnRegresar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Host, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BotonEntrar)
                        .addContainerGap(24, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRegresar)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonEntrarActionPerformed
         String pass=new String(Contraseña.getPassword());
        
         if( Host.getText().isEmpty() || Usuario.getText().isEmpty() || Contraseña.getText().isEmpty())
         {
                        JOptionPane.showMessageDialog(null,"LLene todos los datos", "Error ", JOptionPane.INFORMATION_MESSAGE);
                       // conexionUsuario=crude.Conectar(Direccion, pass, Usuario1);
                        
         }else{
             crude.Conectar("jdbc:mysql://"+Host.getText()+":3306/KND", Usuario.getText(), Contraseña.getText());
            
             if(crude.getValorDeConexionCRUDE()==true){
             switch(getRadioSeleccionadoUsuario())
             {
                 case "Altas":
                        if(Usuario.getText().equals("root")){
                            this.setVisible(false);
                            newAlta.setConexionAltas(crude);
                            newAlta.setVisible(true);
                        }else{
                            JOptionPane.showMessageDialog(this, "Este usuario no tiene permiso para hacer Altas","Permiso denegado", JOptionPane.INFORMATION_MESSAGE);
                        Usuario.setVisible(true);
                        }
                     break;
                 case "Bajas":
                     if(Usuario.getText().equals("root")){
                            this.setVisible(false);
                            newBaja.setConexionBajas(crude);
                            newBaja.setVisible(true);
                        }else{
                            JOptionPane.showMessageDialog(this, "Este usuario no tiene permiso para hacer Altas","Permiso denegado", JOptionPane.INFORMATION_MESSAGE);
                       Usuario.setVisible(true);
                     }
                     break;
                 
                case "Consultar":
                     if(Usuario.getText().equals("Consultor")){
                         Usuario.setVisible(false);
                         newConsultar.setConexionConsultar(crude);
                            newConsultar.setVisible(true);
                        }else{
                            JOptionPane.showMessageDialog(this, "Este usuario no tiene permiso para hacer Altas","Permiso denegado", JOptionPane.INFORMATION_MESSAGE);
                        
                     }
                     break;
                case "Modificar":
                     if(Usuario.getText().equals("root")){
                         this.setVisible(false);
                            newModificar.setConexionModificar(crude);
                            newModificar.setVisible(true);
                        }else{
                            JOptionPane.showMessageDialog(this, "Este usuario no tiene permiso para hacer Altas","Permiso denegado", JOptionPane.INFORMATION_MESSAGE);
                        Usuario.setVisible(true);
                     }
                     return;
             }
             
             
             
         }
         }
    }//GEN-LAST:event_BotonEntrarActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        dispose();
        Usuario.setText("");
        Contraseña.setText("");
        Host.setText("");
        backMenu.setVisible(true);
    }//GEN-LAST:event_btnRegresarActionPerformed
public void setRadioSeleccionadoUsuario(String radio2){
    Radio=radio2;
}

public String getRadioSeleccionadoUsuario(){
    return Radio;
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonEntrar;
    public javax.swing.JPasswordField Contraseña;
    public javax.swing.JTextField Host;
    public javax.swing.JTextField Usuario;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
    CRUD crude=new CRUD();
   String Radio;
   Altas3 newAlta= new Altas3();
   Bajas2 newBaja= new Bajas2();
   Modificar2 newModificar= new Modificar2();
   Consultar2 newConsultar=new Consultar2();
   Menu backMenu= new Menu();
   
   public void setMenuUsuarios(Menu menuP){
       backMenu=menuP;
   }
}
