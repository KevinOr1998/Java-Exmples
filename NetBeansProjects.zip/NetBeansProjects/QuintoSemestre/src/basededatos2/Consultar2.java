
package basededatos2;

import com.mysql.jdbc.Connection;
import javax.swing.JTextField;

public class Consultar2 extends javax.swing.JFrame {

    public Consultar2() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MatriculaConsultar = new javax.swing.JTextField();
        BtnBuscarConsultar = new javax.swing.JButton();
        NombreConsultar = new javax.swing.JTextField();
        ApMaternoConsultar = new javax.swing.JTextField();
        ApPaternoConsultar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        BtnAvanzadaConsultar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setTitle("CONSULTA NORMAL");

        BtnBuscarConsultar.setText("Buscar");
        BtnBuscarConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarConsultarActionPerformed(evt);
            }
        });

        NombreConsultar.setEditable(false);
        NombreConsultar.setToolTipText("");

        ApMaternoConsultar.setEditable(false);

        ApPaternoConsultar.setEditable(false);

        jLabel2.setText("Nombre");
        jLabel2.setToolTipText("");

        jLabel3.setText("Materno");

        jLabel4.setText("Paterno");

        BtnAvanzadaConsultar.setText("Consulta avanzada");
        BtnAvanzadaConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAvanzadaConsultarActionPerformed(evt);
            }
        });

        jLabel1.setText("Ingresar matricula");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(MatriculaConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BtnBuscarConsultar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4)))
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ApPaternoConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NombreConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ApMaternoConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(92, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BtnAvanzadaConsultar)
                .addGap(53, 53, 53))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(MatriculaConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnBuscarConsultar))
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NombreConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ApPaternoConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ApMaternoConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addComponent(BtnAvanzadaConsultar)
                .addGap(31, 31, 31))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnBuscarConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarConsultarActionPerformed
        crudConsultar=getConexionConsultar();
        crudConsultar.ConsultaNormal(MatriculaConsultar.getText());
        NombreConsultar.setText(crudConsultar.getNombre());
        ApPaternoConsultar.setText(crudConsultar.getA_paterno());
        ApMaternoConsultar.setText(crudConsultar.getA_materno());
    }//GEN-LAST:event_BtnBuscarConsultarActionPerformed

    private void BtnAvanzadaConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAvanzadaConsultarActionPerformed
        this.setVisible(false);
        newAdvance.setVisible(true);
        
    }//GEN-LAST:event_BtnAvanzadaConsultarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ApMaternoConsultar;
    private javax.swing.JTextField ApPaternoConsultar;
    private javax.swing.JButton BtnAvanzadaConsultar;
    private javax.swing.JButton BtnBuscarConsultar;
    private javax.swing.JTextField MatriculaConsultar;
    private javax.swing.JTextField NombreConsultar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
Connection conexionConsultar=null;
CRUD crudConsultar=new CRUD();
ConsultaAvanzada newAdvance=new ConsultaAvanzada();
   public void setConexionConsultar(CRUD conexion){
        crudConsultar=conexion;
    }
   public  CRUD getConexionConsultar(){
        return crudConsultar;
    }
}
