/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quintosemestre;
import java.util.Scanner;
/**
 *
 * @author Kevin Ortega
 */
public class NewClass {
    public static void main(String args[]){
        Scanner teclado=new Scanner(System.in);
        System.out.println("Cual es tu numero de intervalos?");
        int n=teclado.nextInt();   
        
        float a=0;
        float b= (float) (3.1416/2);
        double h= ((b-a)/n);
        
        double sumatoria=0;
        
        for(double k=0; k<n;k++)
        {
            
         
        }
    }
        public double funcionA(double a)
        {double cos=0;
            a= Math.toRadians(a);
            cos= Math.cos(a);
            return cos; 
    }
    
}
