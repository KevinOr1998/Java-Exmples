/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SegundoParcial;

import java.util.Scanner;

/**
 *
 * @author Ramos Angel
 */
public class CrearMatriz2 {
    
    static void muestramatriz(float matriz[][], int var) {
        for (int x = 0; x < var; x++) {
            for (int y = 0; y < (var + 1); y++) {
                System.out.print(" " + matriz[x][y] + " |");
            }
            System.out.println("");
        }

    }

    static void pivote(float matriz[][], int piv, int var) {
        float temp = 0;
        temp = matriz[piv][piv];
        for (int y = 0; y < (var + 1); y++) {

            matriz[piv][y] = matriz[piv][y] / temp;
        }
    }

    static void hacerceros(float matriz[][], int piv, int var) {
        for (int x = 0; x < var; x++) {
            if (x != piv) {
                float c = matriz[x][piv];
                for (int z = 0; z < (var + 1); z++) {
                    matriz[x][z] = ((-1 * c) * matriz[piv][z]) + matriz[x][z];
                }
            }
        }
    }
    
    
    
    
    

    public static void main(String[] args) {
        int  piv = 0;
        Scanner teclado = new Scanner(System.in);
        System.out.println(" cuantos puntos tiene e polinomio? ");
        int puntos = teclado.nextInt();
        float[][] punto = new float[2][puntos];

        //se llena la matriz de puntos
        for (int i = 0; i <= 1; i++) {
            for (int j = 0; j < punto[0].length; j++) {
                if (i < 1) {
                    System.out.println(" dime el valor de: X" + (j + 1));
                    punto[i][j] = teclado.nextInt();
                } else {
                    System.out.println(" dime el valor de: Y" + (j + 1));
                    punto[i][j] = teclado.nextInt();
                }
            }
        }//se muestran las coordenadas de los puntos
        for (int y = 0; y < punto.length; y++) {
            System.out.println("");
            for (int z = 0; z < punto[0].length; z++) {
                if (y < 1) {
                    System.out.print("X" + (z + 1) + ": " + punto[y][z] + " ");
                } else {
                    System.out.print("Y" + (z + 1) + ": " + punto[y][z] + " ");
                }
            }

        }
        //generando matriz principal
        int fias = puntos;
        int columnas = puntos + 1;
        //generando matriz de VaderMonde

        float matrisV[][] = new float[fias][columnas];
        float n;
        for (int i = 0; i < matrisV.length; i++) {
            n = punto[0][i];
            for (int j = 0; j < matrisV[0].length; j++) {
                if (j < matrisV.length) {
                    matrisV[i][j] = (float) Math.pow(n, j);
                } else {
                    matrisV[i][j] = punto[1][i];
                }
            }
        }//imprimiendo la matriz de bermonde
        System.out.println("\n Matriz de Vadermonde: ");

        for (int i = 0; i < matrisV.length; i++) {
            System.out.println("");
            for (int j = 0; j < matrisV[0].length; j++) {
                System.out.print(matrisV[i][j] + "      |      ");
            }
        }
        
        
        
        
        
        
         for (int a = 0; a < puntos; a++) {
            pivote(matrisV, piv, puntos);

            System.out.println("\tRenglon " + (a + 1) + " entre el pivote");
            muestramatriz(matrisV, puntos);//llama a metodo muestramatriz

            System.out.println("");

            System.out.println("\tHaciendo ceros");
            hacerceros(matrisV, piv, puntos);//lama a metodo hacerceros

            muestramatriz(matrisV, puntos);//llama nuevamente al metodo muestramatriz
            System.out.println("");
            piv++;
        }
        for (int x = 0; x < puntos; x++) {
            System.out.println("La variable a" + (x) + " es: " + matrisV[x][puntos]);// muestra el valor de las variables
        }

    }

}
