/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneradorNumeroAleatorio;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JSpinner;

/**
 *
 * @author Kevin Ortega
 */
public class Generador extends JFrame
{
  private JLabel lbnumero1;
  private JLabel lbnumero2;
  private JLabel lbnumeroG;
  private JButton btngenerar;
  private JSpinner spnumero1;
  private JSpinner spnumero2;
  private JTextField campo;
  
  public Generador()
          {
              super("Generador de numeros");
              setLayout(new FlowLayout());
              
              lbnumero1=new JLabel("NUMERO 1",SwingConstants.LEFT);
              add(lbnumero1);
              
              spnumero1=new JSpinner();
              spnumero1.setSize(new Dimension(30,10));
              add(spnumero1);
              
              lbnumero2=new JLabel("NUMERO 2",SwingConstants.CENTER);
              add(lbnumero2);
             
              spnumero2=new JSpinner();
              spnumero2.setSize(new Dimension(30,10));
              add(spnumero2);
              
              lbnumeroG=new JLabel("NUMERO GENERADO",SwingConstants.LEFT);
              add(lbnumeroG);
              
              campo=new JTextField(10);
              campo.setHorizontalAlignment(SwingConstants.RIGHT);
              campo.setEditable(false);
              campo.setBackground(Color.WHITE);
              
              add(campo);
              
              btngenerar=new JButton("Generar");
              btngenerar.setVerticalAlignment(SwingConstants.BOTTOM);
              add(btngenerar);
             
              BotonGenerarNumero generator=new BotonGenerarNumero();
              btngenerar.addActionListener(generator);
              
              
          }
    private class BotonGenerarNumero implements ActionListener
    {
        public void actionPerformed(ActionEvent evento)
        {
            int numero11=(int)spnumero1.getValue();
            int numero22=(int)spnumero2.getValue();
            String numeroGenerado=String.valueOf(generaNumeroAleatorio(numero11,numero22));
            
            campo.setText(numeroGenerado);
            
            
        }

 
    }
    private int generaNumeroAleatorio(int minimo, int maximo){
         
        int num=(int)Math.floor(Math.random()*(minimo-(maximo+1))+(maximo+1));
        return num;
    }
}
