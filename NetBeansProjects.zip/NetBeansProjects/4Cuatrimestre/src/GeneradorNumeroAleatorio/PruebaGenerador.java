/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneradorNumeroAleatorio;


import javax.swing.JFrame;

/**
 *
 * @author Kevin Ortega
 */
public class PruebaGenerador
{
     public static void main( String args[] ) {
Generador marcoEtiqueta = new Generador( ); // crea objeto LabelFrame
 marcoEtiqueta.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
 marcoEtiqueta.setSize( 300, 180 ); // establece el tamaño del marco
 marcoEtiqueta.setVisible( true ); // muestra el marco
 } 
    
}
