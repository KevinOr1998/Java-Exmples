package MarcoButon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kevin Ortega
 */

import java.awt.FlowLayout;
 import java.awt.event.ActionListener;
 import java.awt.event.ActionEvent;
 import javax.swing.JFrame;
 import javax.swing.JButton;
 import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class MarcoBoton extends JFrame {
       
 private JButton botonJButtonSimple; // botón con texto solamente
 private JButton botonJButtonElegante;//botón con iconos
    
         public MarcoBoton()
          {
              super( "Boton Simple" );
              setLayout( new FlowLayout() ); // establece el esquema del marco
              
              botonJButtonSimple=new JButton("Boton Simple");
              add(botonJButtonSimple);
              
              Icon Lindsey1=new ImageIcon(getClass().getResource("Lindsey1.jpg"));
              Icon Lindsey2=new ImageIcon(getClass().getResource("Lindsey2.jpg"));
              
              botonJButtonElegante=new JButton("Boton Elegante",Lindsey1);
              botonJButtonElegante.setRolloverIcon(Lindsey2);
              add(botonJButtonElegante);
              
              ManejadorBoton manejador = new ManejadorBoton();
              botonJButtonElegante.addActionListener( manejador );
              botonJButtonSimple.addActionListener( manejador );
       }
              private class ManejadorBoton implements ActionListener
            {
 
                 public void actionPerformed( ActionEvent evento )
                {
                    JOptionPane.showMessageDialog( MarcoBoton.this, String.format("Usted oprimio: %s", evento.getActionCommand() ) );
                } 
} 
              
              
              
              
          }

