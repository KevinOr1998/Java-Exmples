/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Espejo;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;

/**
 *
 * @author Kevin Ortega
 */
public class Espejo
{
    private JCheckBox ckb1Imitacion;
    private JCheckBox ckb1Original;
    private JCheckBox ckb2Imitacion;
    private JCheckBox ckb2Original;
    private JCheckBox ckb3Imitacion;
    private JCheckBox ckb3Original;
    private JComboBox cmbImitacion;
    private JComboBox cmbOriginal;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JSeparator jSeparator1;
    private JRadioButton rdb1Imitacion;
    private JRadioButton rdb1Original;
    private JRadioButton rdb2Imitacion;
    private JRadioButton rdb2Original;
    private JRadioButton rdb3Imitacion;
    private JRadioButton rdb3Original;
    private JSpinner spnImitacion;
    private JSpinner spnOriginal;
    private JTextField txtImitacion;
    private JTextField txtOriginal;
    
}
