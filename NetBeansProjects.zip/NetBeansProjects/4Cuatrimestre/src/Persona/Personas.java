/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persona;
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import javax.swing.JTextField;


/**
 *
 * @author Kevin Ortega
 */
public class Personas extends JFrame
        
{
    private JLabel especialidad;
    private JLabel sistema;
    private JRadioButton windows;
    private JRadioButton mac;
    private JRadioButton linux;
    private JCheckBox programacion;
    private JCheckBox diseñoGrafico;
    private JCheckBox  administracion;
    private JLabel horasLabel;
    private JButton generar;
    private ButtonGroup grupoOpciones;
    private JTextField tfNombre;

    public Personas()
    {
        super("Personas");
        setLayout(null);
        
        //jlabel
        
        windows=new JRadioButton("Niño");
        windows.setBounds(110,50,50,50);
        windows.setVerticalTextPosition(JRadioButton.TOP);
        windows.setHorizontalTextPosition(JRadioButton.CENTER);
        
        mac=new JRadioButton("Joven");
        mac.setBounds(10,50,50,50);
        mac.setVerticalTextPosition(JRadioButton.TOP);
        mac.setHorizontalTextPosition(JRadioButton.CENTER);
        
        linux=new JRadioButton("Adulto");
        linux.setBounds(60,50,50,50);
        linux.setVerticalTextPosition(JRadioButton.TOP);
        linux.setHorizontalTextPosition(JRadioButton.CENTER);
        
        sistema=new JLabel("Nombre");
        sistema.setBounds(10,10,50,50);
        add(sistema);
        //aqui va el textfield
        
        tfNombre=new JTextField(25);
        tfNombre.setBounds(70,25,150,25);
        add(tfNombre);
        
        
        
      grupoOpciones = new ButtonGroup(); // crea ButtonGroup
        grupoOpciones.add( windows ); // agrega simple al grupo
        grupoOpciones.add( mac ); // agrega negrita al grupo
        grupoOpciones.add( linux ); // agrega cursiva al grupo
        add(windows);
        add(linux);
        add(mac);
        
        
        programacion=new JCheckBox("Estudia");
        programacion.setBounds(10,100,80,50);
        programacion.setHorizontalTextPosition(SwingConstants.LEFT);
        add(programacion);
        
        diseñoGrafico=new JCheckBox("Trabaja");
        diseñoGrafico.setBounds(10,140,80,50);
        diseñoGrafico.setHorizontalTextPosition(SwingConstants.LEFT);
        add(diseñoGrafico);
        
        administracion=new JCheckBox("Juega  ");
        administracion.setBounds(10,180,80,50);
        administracion.setHorizontalTextPosition(SwingConstants.LEFT);
        add(administracion);

        
        generar=new JButton("Imprimir");
        generar.setBounds(80,230,100,25);
        add(generar);
        
        ManejadorEncuesta manejador=new ManejadorEncuesta();
        generar.addActionListener(manejador);   
    }
    
        private class ManejadorEncuesta implements ActionListener
    {
        
        public void actionPerformed(ActionEvent evento)
        {
            String informacion="Tu nombre es "+tfNombre.getText()+" y eres un ";
            
            JCheckBox[] arregloBox={programacion,diseñoGrafico,administracion};
             JRadioButton[] arregloRadio={windows,mac,linux};
             
             for(int i=0; i<arregloRadio.length;i++)
             {
                 if(arregloRadio[i].isSelected())
                 {
                     informacion+=arregloRadio[i].getText();
                 }
             }
             informacion+="\n, tus ocupaciones son: ";
             
             for(int i=0; i<arregloBox.length;i++)
             {
                if(arregloBox[i].isSelected())
                 {
                     informacion+=arregloBox[i].getText()+", ";
                 }  
             }
             
        
                 
             JOptionPane.showMessageDialog(null,informacion,"MUESTRA DE DATOS",JOptionPane.INFORMATION_MESSAGE);
             
        }
        
    }
 
        
        
    
}
