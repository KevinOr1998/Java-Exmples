/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CuartoCuatrimestre;

import javax.swing.JFrame;

/**
 *
 * @author Kevin Ortega
 */
public class PruebaLabel {
    
    public static void main( String args[] )
 {
LabelFrame marcoEtiqueta = new LabelFrame(); // crea objeto LabelFrame
 marcoEtiqueta.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
 marcoEtiqueta.setSize( 275, 180 ); // establece el tamaño del marco
 marcoEtiqueta.setVisible( true ); // muestra el marco
 } // fin de main
} // fin de la clase PruebaLabel
    

