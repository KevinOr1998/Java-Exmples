/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CuartoCuatrimestre;

import javax.swing.JOptionPane;

/**
 *
 * @author Kevin Ortega
 */
public class DialogoWindow {
   
    public static void main(String args[]){
     String _numeroUno=JOptionPane.showInputDialog("INTRODUCE EL NUMERO UNO");
     String _numeroDos=JOptionPane.showInputDialog("INTRODUCE EL NUMERO DOS");

     int a=Integer.parseInt(_numeroUno);
     int b=Integer.parseInt(_numeroDos);
    int suma=a+b;
    
    
   
    JOptionPane.showMessageDialog(null, "LA SUMA ES "+suma,"suma de dos enteros", JOptionPane.ERROR_MESSAGE);
    
    }
}

