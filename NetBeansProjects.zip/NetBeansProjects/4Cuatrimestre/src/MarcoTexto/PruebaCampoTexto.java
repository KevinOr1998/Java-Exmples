/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MarcoTexto;

import MarcoTexto.CampoTextoMarco;
import javax.swing.JFrame;

/**
 *
 * @author Kevin Ortega
 */
public class PruebaCampoTexto {
     public static void main( String args[] ){
        CampoTextoMarco campoTextoMarco = new CampoTextoMarco();
        campoTextoMarco.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        campoTextoMarco.setSize( 200, 150 );
        // establece el tamaño del marco
        campoTextoMarco.setVisible( true ); // muestra el marco
    }// fin de main
    
}
