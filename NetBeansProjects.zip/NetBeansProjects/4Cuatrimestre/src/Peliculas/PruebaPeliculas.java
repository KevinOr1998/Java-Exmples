/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Peliculas;

import SaludadorPersonalizable.Saludador;
import javax.swing.JFrame;

/**
 *
 * @author Kevin Ortega
 */
public class PruebaPeliculas
{
           public static void main( String args[] )
 {
Peliculas marcoEtiqueta = new Peliculas(); // crea objeto LabelFrame
 marcoEtiqueta.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
 marcoEtiqueta.setSize( 275, 180 ); // establece el tamaño del marco
 marcoEtiqueta.setVisible( true ); // muestra el marco
 } 
    
    
}
