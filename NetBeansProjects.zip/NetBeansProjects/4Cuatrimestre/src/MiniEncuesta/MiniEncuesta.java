/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MiniEncuesta;


import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.event.ChangeListener;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import javax.swing.JSlider;
import javax.swing.JSeparator;
import javax.swing.event.ChangeEvent;


/**
 *
 * @author Kevin Ortega
 */
public class MiniEncuesta extends JFrame
{
    private JLabel especialidad;
    private JLabel sistema;
    private JRadioButton windows;
    private JRadioButton mac;
    private JRadioButton linux;
    private JSlider horas;
    private JSeparator separador1;
    private JSeparator separador2;
    private JCheckBox programacion;
    private JCheckBox diseñoGrafico;
    private JCheckBox  administracion;
    private JLabel horasLabel;
    private JButton generar;
    private JLabel numero;
    private ButtonGroup grupoOpciones;

    public MiniEncuesta()
    {
        super("MINI ENCUESTA");
        setLayout(new FlowLayout());
        
        windows=new JRadioButton("Windows");
        mac=new JRadioButton("Mac");
        linux=new JRadioButton("Linux");
        
        sistema=new JLabel("Elige un sistema operativo");
        sistema.setVerticalAlignment(SwingConstants.CENTER);
        add(sistema);
        
      grupoOpciones = new ButtonGroup(); // crea ButtonGroup
        grupoOpciones.add( windows ); // agrega simple al grupo
        grupoOpciones.add( mac ); // agrega negrita al grupo
        grupoOpciones.add( linux ); // agrega cursiva al grupo
        add(windows);
        add(linux);
        add(mac);
        separador1=new JSeparator();
       separador1.setVisible(true);
       separador1.setSize(10,10);
        
        
        especialidad=new JLabel("Elige tus especialidades", SwingConstants.CENTER);
        add(especialidad);
        
        programacion=new JCheckBox("Programacion");
        programacion.setHorizontalTextPosition(SwingConstants.LEFT);
        add(programacion);
        
        diseñoGrafico=new JCheckBox("Diseño Grafico");
        diseñoGrafico.setHorizontalTextPosition(SwingConstants.LEFT);
        add(diseñoGrafico);
        
        administracion=new JCheckBox("Administracion");
        administracion.setHorizontalTextPosition(SwingConstants.LEFT);
        add(administracion);
        
        separador2=new JSeparator();
        add(separador1);
        
        horasLabel=new JLabel("Horas que dedicas en el ordenador", SwingConstants.CENTER);
        horasLabel.setToolTipText("label: horasLabel");
        add(horasLabel);
        
        numero=new JLabel("",SwingConstants.LEFT);
        add(numero);
        
        horas=new JSlider();
        horas.setMinimum(1);
        horas.setMaximum(10);
        horas.setValue(0);
        add(horas);
        
        generar=new JButton("Generar");
        generar.setHorizontalAlignment(SwingConstants.CENTER);
        add(generar);
        
        ManejadorEncuesta manejador=new ManejadorEncuesta();
        LabelHorasManejador manejadorHoras=new LabelHorasManejador();
        
        generar.addActionListener(manejador);
        horas.addChangeListener(manejadorHoras);
        
        
        
    }
    
        private class ManejadorEncuesta implements ActionListener
    {
        
        public void actionPerformed(ActionEvent evento)
        {
            String informacion="Tu sistema operativo es ";
            
            JCheckBox[] arregloBox={programacion,diseñoGrafico,administracion};
             JRadioButton[] arregloRadio={windows,mac,linux};
             
             for(int i=0; i<arregloRadio.length;i++)
             {
                 if(arregloRadio[i].isSelected())
                 {
                     informacion+=arregloRadio[i].getText();
                 }
             }
             informacion+="\n tus especalidades son: ";
             
             for(int i=0; i<arregloBox.length;i++)
             {
                if(arregloBox[i].isSelected())
                 {
                     informacion+=arregloBox[i].getText()+", ";
                 }  
             }
             
             informacion+=" \n y el numero de horas dedicadas en el ordenador son "+horas.getValue()+"."+"\n Y SERRANO ES PUTO POR SIEMPRE";
                 
             JOptionPane.showMessageDialog(null,informacion,"MUESTRA DE DATOS",JOptionPane.INFORMATION_MESSAGE);
             
        }
        
    }
     

        private class LabelHorasManejador implements ChangeListener
        {
          
            public void stateChanged(ChangeEvent evento) 
            {
             numero.setText(String.valueOf(horas.getValue())); 
            }
        }
        
        

}
