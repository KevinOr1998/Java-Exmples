/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane; 

/**
 *
 * @author ChemaCs
 */
public class ConexionBDEsclavo{
 
    Connection cn;
    
 public Connection conexion(){
 
     try{
         Class.forName("com.mysql.jdbc.Driver");
         cn = DriverManager.getConnection("jdbc:mysql://localhost/escuela","root","");
         
         //"jdbc:mysql://192.168.43.22/UPEG","Esclavo","cisco8702"
         System.out.println("Se hizo la conexión exitosamente");
         
     }catch(Exception e){
         System.out.println(e.getMessage());
     }return cn;
     }
      Statement createStatement(){
          throw new UnsupportedOperationException("No soportado");
         
     }
 
 
 
 
 
 
 }










