/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ChemaCs
 */
public class ConexionBDMaestro{
 
    Connection cn;
    
 public Connection conexion(){
 
     try{
         Class.forName("com.mysql.jdbc.Driver");
         cn = DriverManager.getConnection("jdbc:mysql://192.168.43.100/UPEG","maestro","maestro");
         //"jdbc:mysql://192.168.43.154/UPEG","Maestro","cisco8702"
         System.out.println("Se hizo la conexión exitosamente");
         
     }catch(Exception e){
         System.out.println(e.getMessage());
     }return cn;
     }
      Statement createStatement(){
          throw new UnsupportedOperationException("No soportado");
         
     }
 
 
 
 
 
 
 }










