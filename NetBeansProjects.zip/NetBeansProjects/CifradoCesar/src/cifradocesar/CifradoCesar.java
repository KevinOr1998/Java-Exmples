package cifradocesar;
import java.util.Scanner;

/**
 *
 * @author Kevin Ortega
 */
public class CifradoCesar{
   private static final  char [] abc={'a','b','c','d','e','f','g',
                       'h','i','j','k','l','m',
                       'n','�','o','p','q','r','s',
                       't','u','v','w','x','y',
                       'z'};
   private static final char [] acentos={'a','e','i','o','u',};
    private static int pointer=0;
    private static int h=0;
    private static String tp="";
    private static int saltos=-1;
    private static  Scanner datoStr  =new Scanner(System.in);
    private static  Scanner datoInt  =new Scanner(System.in);
    private static String tc="";
    private static int option;
    
   public static void main(String[] args) {
    
    while(true ){
        System.out.println("�Que quieres hacer?");
        System.out.println("1.- Cifrar");
        System.out.println("2.- Descifrar");
        System.out.println("3.- Salir");
        option=datoInt.nextInt();
        switch(option)
        {
            case 1 :
                if(setDatos()==true){
                System.out.println("******Texto cifrado*****\n"+Cifrar(tp,saltos));
                }else{
                    System.out.println("Error al ingresar los datos");
                }
                break;
            case 2:
                setDatos();
                System.out.println("******Texto descifrado*****\n"+Descifrar(tp,saltos));
                break;
            case 3:
               return;
            default:
                System.out.println("ERROR: Elige solo las opciones 1,2 o 3");
        }  
    }
   }   
   private static String Cifrar(String txtP, int jumps) {
       tc=""; 
       pointer=0;
       txtP=txtP.toLowerCase();
        char [] txt=txtP.toCharArray();
        for(int i=0;i<txt.length;i++)
        {
            if(txt[i]==' ')
            {
                tc+=" ";
                continue;
            }
            for(int k=0;k<abc.length;k++)
            {
                if(txt[i]==abc[k] || txt[i]==acentos[pointer]  )
                {
                    if((k+jumps)<abc.length){
                        h=k+jumps;
                    }else{
                        h=((k-abc.length)+jumps);
                    }
                tc+=abc[h];
                break;
                }
                pointer++;
            }        
        }
    return tc;
   }
   private static String Descifrar(String txtP, int jumps){
       tc="";
        txtP=txtP.toLowerCase();
        char [] txt=txtP.toCharArray();
        for(int i=0;i<txt.length;i++)
        {
            if(txt[i]==' ') 
            {
                tc+=" " ;
                continue;
            }
            for(int k=26;k>=0 && k<abc.length;k--)
            {
                if(txt[i]==abc[k])
                {
                    if((k-jumps)>=0){
                        h=k-saltos;
                    }else{
                        h=((k+abc.length)-jumps);
                    }
                tc+=abc[h];               
                }         
            }        
        }
    return tc;
   }
   private static boolean setDatos(){
                saltos=0;
                
                    System.out.println("Introduce tu texto");
                    tp=datoStr.nextLine();
                    char [] txt2=tp.toCharArray();
                    for(int r=0;r<txt2.length;r++){
                        if(txt2[r]=='1' || txt2[r]=='2' || txt2[r]=='3' || txt2[r]=='4' || txt2[r]=='5' || txt2[r]=='6' || txt2[r]=='7' || txt2[r]=='8' ||  txt2[r]=='9' || txt2[r]=='0' ){
                            saltos=-1;
                            break;
                        }
                    }
                    if(saltos==-1){
                    System.out.println("ERROR");
                       return false;
                    }else{
                        while (saltos<=0 || saltos>26)
                        {
                            System.out.println("Introduce un numero de saltos para cifrar, el numero debe ser mayor o igual que 1 pero menor a 27");
                            saltos=(int)datoInt.nextInt();
                        }  
                        return true;
                    }      
   }
}