/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VariableCompleja;

/**
 *
 * @author sarai
 */
import java.util.Scanner;
import java.lang.Math;
import java.text.DecimalFormat;

public class VariableCompleja2 {

    public static void main(String[] args) throws InterruptedException {

        Scanner entrada = new Scanner(System.in);
        double x1 = 0, yi1 = 0, x2 = 0, yi2 = 0;
        double Mod1 = 0;
        double Mod2 = 0;
        boolean des = true;
        while (des == true) {

            System.out.println("******************BIENVENIDO************************");

            //calculando modulos 
            //seleccion de la opciones del menú
            Scanner opcion = new Scanner(System.in);
            System.out.println("*****************Menu****************** \n1.- Suma \n2.- Resta \n3.- Multiplicacion\n4.- Division\n5.- Exponente\n6.- Raiz \n7.- Salir");
            int num = opcion.nextInt();

            if (num == 1 || num == 2 || num == 3 || num == 4) {
                System.out.println("A continuacion ingresará los valores de Z1(x1 + yi1)");
                System.out.println("Ingresa x1: ");
                x1 = entrada.nextDouble();

                System.out.println("Ingresa yi1: ");
                yi1 = entrada.nextDouble();

                System.out.println("A continuacion ingresará los valores de Z2(x2 + yi2)");
                System.out.println("Ingresa x2:");
                x2 = entrada.nextDouble();

                System.out.print("Ingresa yi2:\n ");
                yi2 = entrada.nextDouble();
                Mod1 = Math.sqrt((x1 * x1) + (yi1 * yi1));
                Mod2 = Math.sqrt((x2 * x2) + (yi2 * yi2));
            } else if (num == 5 || num == 6) {
                System.out.println("A continuacion ingresará los valores de Z1(x1 + yi1)");
                System.out.println("Ingresa x1: ");
                x1 = entrada.nextDouble();

                System.out.println("Ingresa yi1: ");
                yi1 = entrada.nextDouble();
                Mod1 = Math.sqrt((x1 * x1) + (yi1 * yi1));
            }
            //  System.out.println();
            System.out.println("**************************************************");
            switch (num) {
                case 1:
                    System.out.println("+++SUMA+++");
                    Suma(x1, yi1, x2, yi2);
                    break;

                case 2:
                    System.out.println("+++RESTA+++");
                    Resta(x1, yi1, x2, yi2);

                    break;

                case 3:
                    System.out.println("+++MULTIPLICACION+++");
                    Multiplicacion(x1, yi1, x2, yi2, Mod1, Mod2);

                    break;

                case 4:
                    System.out.println("+++DIVISION+++");
                    Division(x1, yi1, x2, yi2, Mod1, Mod2);

                    break;

                case 5:
                    System.out.println("+++EXPONENTE+++");
                    Exponente(x1, yi1, x2, yi2, Mod1, Mod2);
                    break;

                case 6:
                    System.out.println("+++RAIZ+++");
                    Raiz(x1, yi1, x2, yi2, Mod1, Mod2);

                    break;

                case 7:
                    System.out.println("+++SALISTE+++");
                    return;
            }
            System.out.println("**************************************************");
            System.out.println("Quieres hacer otra operacion?");
            System.out.println("<escribe true or false>");
            des = entrada.nextBoolean();
            for (int i = 0; i < 5; i++) {
                String cargando = "#";
                if (i == 0) {
                    System.out.print("CARGANDO" + cargando);
                }
                Thread.sleep(500);
                System.out.print(cargando);
            }
            System.out.println("\n-----------------------------------------------------------");
        }
        System.out.println("\n¡¡¡SALISTE!!!");
    }

    public static double Angulo(double x, double y) {
        double teta = 0;
        if (x >= 0 && y >= 0) {
            teta = Math.atan(y / x);
        }
        if (x < 0 && y >= 0) {
            teta = Math.atan(y / x) + Math.PI;
        }
        if (x < 0 && y < 0) {
            teta = Math.atan(y / x) + Math.PI;
        }
        if (x >= 0 && y < 0) {
            teta = Math.atan(y / x) + (2 * Math.PI);
        }

        return teta;
    }

    public static void Suma(double x1, double yi1, double x2, double yi2) {

        double Real = x1 + x2;
        double Imaginario = yi1 + yi2;
        if (Imaginario > 0) {
            System.out.println("Resultado " + Math.floor(Real) + "+ " + Math.floor(Imaginario) + "i");
        }
        if (Imaginario < 0) {
            System.out.println("Resultado " + Math.floor(Real) + "- " + Math.floor(Imaginario) + "i");
        }
        if (Imaginario == 0) {
            System.out.println("Resultado " + Math.floor(Real) + "+0");
        }
        if (Real >= 0 && Imaginario >= 0) {
            System.out.println("Primer cuadrante");
        }
        if (Real < 0 && Imaginario >= 0) {
            System.out.println("Segundo cuadrante");
        }
        if (Real < 0 && Imaginario < 0) {
            System.out.println("Tercer cuadrante");
        }
        if (Real >= 0 && Imaginario < 0) {
            System.out.println("Cuarto cuadrante");
        }
    }

    public static void Resta(double x1, double yi1, double x2, double yi2) {
        double Re = x1 - x2;
        double Im = yi1 - yi2;
        System.out.println("Resultado " + Math.floor(Re) + " " + Math.floor(Im) + "i");
        if (Im > 0) {
            System.out.println("Resultado " + Math.floor(Re) + "+ " + Math.floor(Im) + "i");
        }
        if (Im < 0) {
            System.out.println("Resultado " + Math.floor(Re) + "- " + Math.floor(Im) + "i");
        }
        if (Im == 0) {
            System.out.println("Resultado " + Math.floor(Re) + "+0");
        }
        if (Re >= 0 && Im >= 0) {
            System.out.println("Primer cuadrante");
        }
        if (Re < 0 && Im >= 0) {
            System.out.println("Segundo cuadrante");
        }
        if (Re < 0 && Im < 0) {
            System.out.println("Tercer cuadrante");
        }
        if (Re >= 0 && Im < 0) {
            System.out.println("Cuarto cuadrante");
        }

    }

    public static void Multiplicacion(double x1, double yi1, double x2, double yi2, double Mod1, double Mod2) {
        double multR = x1 * x2 - yi1 * yi2;
        double multIm = x1 * yi2 + x2 * yi1;
        if (multIm > 0) {
            System.out.println("Resultado " + Math.floor(multR) + "+" + Math.floor(multIm) + "i");
        }
        if (multIm < 0) {
            System.out.println("Resultado " + Math.floor(multR) + "-" + Math.floor(multIm) + "i");
        }
        if (multIm == 0) {
            System.out.println("Resultado " + Math.floor(multR) + "+0i");
        }

        //calculanbdo los valores del angulo Z1 Y Z2
        double teta1 = Angulo(x1, yi1);
        double teta2 = Angulo(x2, yi2);
        double tetaMayor = teta1 + teta2;
        DecimalFormat df = new DecimalFormat("#.0000");
        //CALCULANDO R1*R2
        double RM = Mod1 * Mod2;
        //CALCULANDO EL CUADRANTE
        double x = (RM * Math.cos(tetaMayor));
        double y = (RM * Math.sin(tetaMayor));
        System.out.println(df.format(RM) + "CIS" + df.format(tetaMayor));
        if (x >= 0 && y >= 0) {
            System.out.println("Primer cuadrante");
        }
        if (x < 0 && y >= 0) {
            System.out.println("Segundo cuadrante");
        }
        if (x < 0 && y < 0) {
            System.out.println("Tercer cuadrante");
        }
        if (x >= 0 && y < 0) {
            System.out.println("Cuarto cuadrante");
        }
    }

    public static void Division(double x1, double yi1, double x2, double yi2, double Mod1, double Mod2) {

        double DivReal = ((x1 * x2) * (yi1 * yi2)) / ((x2 * x2) * (yi2 * yi2));// 7
        double DivIm = ((x2 * yi1) - (x1 * yi2)) / ((x2 * x2) + (yi2 * yi2));//-1/21
        DecimalFormat df = new DecimalFormat("#0.000000000");

        if (DivReal >= 0 && DivIm >= 0) {
            System.out.println("Z1/Z2=" + df.format(DivReal) + "+" + df.format(DivIm) + "i");
        }
        if (DivReal >= 0 && DivIm < 0) {
            System.out.println("Z1/Z2=" + df.format(DivReal) + "" + df.format(DivIm) + "i");
        }
        if (DivReal < 0 && DivIm >= 0) {
            System.out.println("Z1/Z2=" + df.format(DivReal) + "+" + df.format(DivIm) + "i");
        }
        if (DivReal < 0 && DivIm < 0) {
            System.out.println("Z1/Z2=" + df.format(DivReal) + "" + df.format(DivIm) + "i");
        }

        //calculando cuadrante
        if (DivReal >= 0 && DivIm >= 0) {
            System.out.println("Primer cuadrante");
        }
        if (DivReal < 0 && DivIm >= 0) {
            System.out.println("Segundo cuadrante");
        }
        if (DivReal < 0 && DivIm < 0) {
            System.out.println("Tercer cuadrante");
        }
        if (DivReal >= 0 && DivIm < 0) {
            System.out.println("Cuarto cuadrante");
        }
        //calculando modulo z
        double R = Mod1 / Mod2;
        double tet1 = Angulo(x1, yi1);
        double tet2 = Angulo(x2, yi2);

        double tetaM = tet1 - tet2;
        System.out.println(df.format(R) + "CIS" + df.format(tetaM));
    }

    public static void Exponente(double x1, double yi1, double x2, double yi2, double Mod1, double Mod2) {
        DecimalFormat df = new DecimalFormat("#.00000000");
        Scanner entrada = new Scanner(System.in);
        System.out.println("En que exponente quieres z1:");
        float n = entrada.nextFloat();
        double te1 = Angulo(x1, yi1);
        System.out.println(df.format(Math.pow(Mod1, n)) + " CiS " + df.format(n * te1));
        /*System.out.println("En que exponente quieres z2:");
            float n2=entrada.nextFloat();
            double te2=Angulo(x1,yi1);
            System.out.println(Math.floor(Math.pow(Mod2,n2))+" Cis "+Math.floor(n2*te2));*/
    }

    public static void Raiz(double x1, double yi1, double x2, double yi2, double Mod1, double Mod2) {
        double n = 0;
        double k = 0;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Intruce el exponente de raiz: cuadratica(2), cubica(3), et.");
        n = entrada.nextInt();
        DecimalFormat df = new DecimalFormat("#.0000");

        while (k >= n) {
            System.out.println("Hasta que valor de k quieres calcular las raices, tomandoen cuenta que k debe ser menor que n");
            k = entrada.nextInt();
            if (k >= n) {
                System.out.println("El valor de k debe ser menor");
            }
        }
        for (int K = 0; K <= (n - 1); K++) {
            double T1 = Angulo(x1, yi1);
            System.out.println("Calculando los valores de Z1    K=" + K);
            double r = Math.pow(Mod1, (1.0 / n));
            System.out.println("Calculando el valor exponencial" + df.format(Math.pow(Mod1, (1 / n))));
            double argumento = ((T1 + 2 * K * 3.1416) / (n));
            System.out.println("Forma cis de z1:   " + df.format(r) + " CIS " + df.format(argumento) + "\n");
            /*//calculando z2
                    System.out.println("Calculando los valores de Z2 K="+K);
                    double T2=Angulo(x2,yi2);
                    double r2=Math.pow( Mod2,1/n);
                    double argumento2=((T2+2*K*3.1416)/(n));
                    System.out.println("Forma cis de z2:   "+df.format(r2)+" CIS "+df.format(argumento2)+"\n");   */
        }
    }

}
