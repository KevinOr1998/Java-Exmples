/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quintosemestre;
import java.util.Scanner;


/**
 *
 * @author Kevin Ortega
 */
public class QuintoSemestre {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       String genero;
       String edadNumero;
       int edad;
       Scanner teclado=new Scanner(System.in);
       
       
        System.out.println("¿Cual es tu genero mujer u hombre?");
        genero=teclado.nextLine();
        genero=genero.toLowerCase();
        
        System.out.println("¿Cual es tu edad?");
        edad=teclado.nextInt();
        
        try{
       if(edad>=18)
       {
        
                 if(genero.equals("mujer"))
                 {
                       System.out.println("Pasas gratis");
                 }
                else 
                 {
                       System.out.println("Pasas pero vas a pagar");
                 }
        } 
       else
        {
              System.out.println("No pasas");
        }
    
        }catch(InputMismatchException excenption){
       System.out.println("¿Error al ingresar edad, escribe tu edad en numero");
       
    
    }
}
}
