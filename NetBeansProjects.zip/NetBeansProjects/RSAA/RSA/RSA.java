package rsa;

/**
 *
 * @author Kingkronoz
 */
import java.util.Scanner;

public class RSA {
    private static String  CifradoP;
        private static Scanner sc = new Scanner(System.in);
        private static int[] primos = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47};
        private static int p = 11, q = 19;
        private static int n = p * q;
        private static int teta = (p - 1) * (q - 1);
        private static int e = 0;
        private static int d = 0;
   public  void Cifrar(String mensaje){
       //////////////////////////////////////////////////////////////////////////////
//cifrar//
        char[] abc = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
            'I', 'J', 'K', 'L', 'M', 'N', 'Ñ', 'O', 'P',
            'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

        /*System.out.println("texto a cifrar y enviar");
        String texto = sc.nextLine().toUpperCase();*/
        mensaje =mensaje.toUpperCase();
        char[] textoAr = mensaje.toCharArray();
        int numletra[] = new int[textoAr.length];

        for (int i = 0; i < textoAr.length; i++) {
            for (int j = 0; j < abc.length; j++) {
                if (textoAr[i] == abc[j]) {
                    numletra[i] = j + 1;
                    //System.out.println(numletra[i]);
                    break;
                } else if (textoAr[i] == ' ') {
                    numletra[i] = 0;
                    //System.out.println(numletra[i]);

                    break;
                }
            }
        }//termina el llenado
///////////////////////////////////////////////////////////////////////////////
///cifrando con llave publica//

        double cifletra[] = new double[textoAr.length];
         CifradoP="";
        for (int i = 0; i < numletra.length; i++) {
            cifletra[i]=Math.pow(numletra[i],e)%n;
            CifradoP=CifradoP+" "+(int)cifletra[i];
        }
       // System.out.println(CifradoP);
        
        ////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////
   }
   public  String getCifrado(){
       
       return CifradoP;
   }
   public void CalcularRSA(){
        for (int i = 0; i < primos.length; i++) {
            if ((teta % primos[i]) != 0) {
                e = primos[i];
                break;
            }
        }
        for (int i = 0; i < 100; i++) {
            int cal = ((i + 1) * teta) + 1;
            if (cal % e == 0) {
                d = cal / e;
                break;
            }
        }
   }
   public String Descifrar(String mensaje){
       
       return mensaje;
   }
}
