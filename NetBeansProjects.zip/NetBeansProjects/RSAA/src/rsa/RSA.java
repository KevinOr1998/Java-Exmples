package rsa;

/**
 *
 * @author Kingkronoz & Kevin Ortega
 */
import java.math.BigDecimal;
import java.util.Scanner;
import java.math.BigInteger;

public class RSA {
        private static char[] abc = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
            'I', 'J', 'K', 'L', 'M', 'N', 'Ñ', 'O', 'P',
            'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        private static int[] primos = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47};
        private static int p = 11, q = 19;
        private static int n = p * q;
        private static int teta = (p - 1) * (q - 1);
        private static int e = 0;
        private static int d = 0;

    public static String getTxtDeScifrado(String CifradoP){
        String tdc="";
        String [] tc=CifradoP.split(" ");//separa el texto  cifrado por cada espacio y los mete a un arreglo
        int d2=Integer.parseInt(tc[tc.length-2]);//clave privada-obtiene el penultimo objeto del arreglo que correspode a la llave privada
        int e2=Integer.parseInt(tc[tc.length-1]);//clave publica-obtiene el penultimo objeto del arreglo que correspode a la llave publica
    
        for(int i=0;i<tc.length-2;i++){
            BigDecimal bd=new BigDecimal(Integer.parseInt(tc[i])); //crea un objeto bigdecimal y se inicia con el valor del objeto de la posicion i del arreglo convertido a entero
            BigDecimal bd2=new BigDecimal((double)209); //crea otro objeto bigdecimal con valor de 209
            bd=bd.pow(d2);//eleva el valor actual de bd y lo eleva al valor de d2(103)
            bd=bd.remainder(bd2);//realiza la operacion MOD bd%209
            int j=  (int) bd.doubleValue();//obtiene el valor de bd convertido a double y lo covierte a eero
            tdc+=abc[j-1];//se agrega a la variable string tdc(texto descifrado) cada caracter del arreglo que contiene las letras del abecedario          
        }
         return tdc;   
    }
    public static String getCifrar(String CifradoP){
        
//////////////////////////////////////////////////////////////////////////////
//cifrar//


        //System.out.println("texto a cifrar y enviar");
        //String texto = sc.nextLine().toUpperCase();
        CifradoP=CifradoP.toUpperCase();
        char[] textoAr = CifradoP.toCharArray();
        int numletra[] = new int[textoAr.length];

        for (int i = 0; i < textoAr.length; i++) {
            for (int j = 0; j < abc.length; j++) {
                if (textoAr[i] == abc[j]) {
                    numletra[i] = j + 1;
                   // System.out.println(numletra[i]);
                    break;
                } else if (textoAr[i] == ' ') {
                    numletra[i] = 0;
                    //System.out.println(numletra[i]);

                    break;
                }
            }
        }//termina el llenado
///////////////////////////////////////////////////////////////////////////////
///cifrando con llave publica//

        double cifletra[] = new double[textoAr.length];
        CifradoP="";
        for (int i = 0; i < numletra.length; i++) {
            cifletra[i]=Math.pow(numletra[i],e)%n;
            CifradoP=CifradoP+(int)cifletra[i]+" ";
        }
        CifradoP+=Integer.toString(d)+" "+Integer.toString(e);
        //System.out.println(CifradoP);      
         return CifradoP;
    }
    public static  void CalcularClaves(){
                for (int i = 0; i < primos.length; i++) {
            if ((teta % primos[i]) != 0) {
                e = primos[i];
               // System.out.println("el valor de e = "+e);
                break;
            }
        }
        for (int i = 0; i < 100; i++) {
            int cal = ((i + 1) * teta) + 1;
            if (cal % e == 0) {
                d = cal / e;
                //System.out.println("el valor de d = "+d);
                break;
            }
        }
    }
}
